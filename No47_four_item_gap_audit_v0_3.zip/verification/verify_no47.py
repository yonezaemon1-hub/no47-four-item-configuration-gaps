#!/usr/bin/env python3
"""No.47 exact checks (Python standard library; no external dependencies).

Scope: verifies role-score lemma, rational size identities, and legacy fixed-pair
inventory/fractional-incidence arithmetic for 4-vertex K4 abstract parameters.
Does NOT reconstruct source trees or prove independent novelty.
"""
from __future__ import annotations
from collections import Counter
from fractions import Fraction as Q
from itertools import combinations_with_replacement
import sys
from pathlib import Path
# -I omits the script directory from sys.path; add only our checked-in directory.
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from indep_table_check import verify_one
import json

P = {'X': 1, 'A': 2, 'D': 4, 'UF': -7}
EPS = Q(1, 1000)
LAM = Q(1, 100000)


def check_scores():
    keys = sorted(P)
    combos = list(combinations_with_replacement(keys, 4))
    counts = Counter('zero' if sum(P[k] for k in c) == 0 else ('pos' if sum(P[k] for k in c) > 0 else 'neg') for c in combos)
    zero = [c for c in combos if sum(P[k] for k in c) == 0]
    assert len(combos) == 35
    assert counts == {'pos': 19, 'neg': 15, 'zero': 1}
    assert zero == [tuple(sorted(P))]
    # Raw source items lie in (1/6, 7/30). Hence delta for singles
    # belongs to (-1/30, 1/30); pair delta belongs to (-1/15, 1/15).
    # For every four-item tuple, total perturbation > -4*(1/15)*LAM,
    # and a positive integer score implies load >1.
    assert EPS > 4 * Q(1, 15) * LAM
    # Each transformed item >1/5 even at the uniform very coarse lower bound.
    assert Q(1, 4) - 7*EPS - Q(1, 15)*LAM > Q(1, 5)
    return {'four_role_multisets': len(combos), 'positive': counts['pos'], 'negative': counts['neg'], 'zero': counts['zero'], 'unique_zero': list(zero[0])}


def converted(a, role):
    if role != 'UF':
        assert isinstance(a, Q) and Q(1, 6) < a < Q(7,30)
        delta = a - Q(1, 5)
    else:
        assert len(a) == 2 and all(Q(1, 6) < v < Q(7,30) for v in a)
        delta = sum(a) - Q(2, 5)
    return Q(1, 4) + EPS * P[role] + LAM * delta


def check_sizes():
    samples = [
        (Q(1, 5), Q(1, 5), Q(1, 5), Q(1, 5), Q(1, 5)),
        (Q(19, 100), Q(19, 100), Q(19, 100), Q(19, 100), Q(19, 100)),
        (Q(21, 100), Q(21, 100), Q(21, 100), Q(21, 100), Q(21, 100)),
        (Q(2, 11), Q(7, 33), Q(7, 33), Q(2, 11), Q(7, 33)),
    ]
    for x, a, d, u, f in samples:
        conv = [converted(x,'X'), converted(a,'A'), converted(d,'D'), converted((u,f),'UF')]
        assert all(Q(1, 5) < s < 1 for s in conv)
        assert sum(conv) == 1 + LAM * (sum([x,a,d,u,f])-1)
        assert (sum(conv) <= 1) == (sum([x,a,d,u,f]) <= 1)
    return {'exact_normal_tuple_samples': len(samples), 'symbolic_identity': 'sum(new)=1+lambda*(sum(old)-1)'}



def check_reverse_bound():
    # Let H = abnormal 4-item bins, L= bins with at most 3 items,
    # then L<=4g, H<=12L. Replacing an abnormal four-bin costs at most
    # 7 additional bins; replacing <=3 costs at most 5 additional bins.
    for g in range(101):
        for L in range(4*g+1):
            # Worst case H=12L is sufficient because the expression
            # increases with H.
            H = 12*L
            excess = g+7*H+5*L
            assert excess <= 357*g
    return {'reverse_coefficient': 357, 'g_tested': '0..100', 'inequality': 'g+7H+5L<=357g given H<=12L,L<=4g'}


def main():
    out={'test_scope': 'exact arithmetic; source-table fixture; no giant source trees, LP solver, or Lean',
         'scores': check_scores(),
         'sizes': check_sizes(),
         'fixed_pair_cases': [
             verify_one(2,3,[4,6,8,10],[4,6,8,10]),
             verify_one(2,4,[5,7,8,9],[4,5,7,11]),
             verify_one(3,4,[8,9,10,12],[7,8,9,11]),
             verify_one(4,5,[12,13,14,16],[11,12,13,14])],
         'reverse': check_reverse_bound(),
         'status': 'PASS (for coded assertions only)'}
    print(json.dumps(out, indent=2, ensure_ascii=False, sort_keys=True))

if __name__ == '__main__':
    main()
