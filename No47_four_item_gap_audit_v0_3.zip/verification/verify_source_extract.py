#!/usr/bin/env python3
"""Optional fail-closed original-source check, Python -I compatible.

Provide five original OpenAI .tex files. First verifies *every* Git blob
SHA against SOURCE_REFERENCES.json, then parses all nine local-state rows
and all four five-role patterns and checks their numerical interpretation.
No Internet needed. Missing source -> no PASS (not counted as a failure of
core arithmetic checks). The bundle does NOT embed original .tex sources.
"""
from pathlib import Path
import hashlib,json,sys
S=Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0,str(S))
from source_table_parser import audit_tables
REF=json.loads((S.parent/'audit/SOURCE_REFERENCES.json').read_text(encoding='utf-8'))
TABLE=json.loads((S/'source_local_state_table.json').read_text(encoding='utf-8'))

def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()

def verify(directory):
    directory=Path(directory)
    paths={x['filename']:x for x in REF['primary_source']['files']}
    if len(paths)!=5:raise AssertionError('Source lock should have five files')
    texts={}
    for name,meta in sorted(paths.items()):
        path=directory/name
        b=path.read_bytes()
        if blob(b)!=meta['git_blob_sha']:
            raise AssertionError(f'FAIL: {name} Git blob SHA mismatch')
        texts[name]=b.decode('utf-8')
    result=audit_tables(texts['instance.tex'],texts['completeness.tex'],TABLE)
    result['git_blob_sha_verified_files']=len(paths)
    print(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2))
    return result

if __name__=='__main__':
    if len(sys.argv)!=2:sys.exit('usage: python -I verification/verify_source_extract.py /path/to/official/source-tex-directory')
    try:verify(Path(sys.argv[1]))
    except Exception as e:raise SystemExit('FAIL '+str(e))
