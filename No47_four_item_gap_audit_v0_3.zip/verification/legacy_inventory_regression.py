#!/usr/bin/env python3
"""No.47 exact checks (Python standard library; no external dependencies).

Scope: verifies role-score lemma, rational size identities, and legacy fixed-pair
inventory/fractional-incidence arithmetic for 4-vertex K4 abstract parameters.
Does NOT reconstruct source trees or prove independent novelty.
"""
from __future__ import annotations
from collections import Counter
from fractions import Fraction as Q
from itertools import combinations_with_replacement
import json

P = {'X': 1, 'A': 2, 'D': 4, 'UF': -7}
EPS = Q(1, 1000)
LAM = Q(1, 100000)


def check_scores():
    keys = sorted(P)
    combos = list(combinations_with_replacement(keys, 4))
    counts = Counter('zero' if sum(P[k] for k in c) == 0 else ('pos' if sum(P[k] for k in c) > 0 else 'neg') for c in combos)
    zero = [c for c in combos if sum(P[k] for k in c) == 0]
    assert len(combos) == 35
    assert counts == {'pos': 19, 'neg': 15, 'zero': 1}
    assert zero == [tuple(sorted(P))]
    # Raw source items lie in (1/6, 7/30). Hence delta for singles
    # belongs to (-1/30, 1/30); pair delta belongs to (-1/15, 1/15).
    # For every four-item tuple, total perturbation > -4*(1/15)*LAM,
    # and a positive integer score implies load >1.
    assert EPS > 4 * Q(8, 5) * LAM
    # Each transformed item >1/5 even at the uniform very coarse lower bound.
    assert Q(1, 4) - 7*EPS - Q(1, 15)*LAM > Q(1, 5)
    return {'four_role_multisets': len(combos), 'positive': counts['pos'], 'negative': counts['neg'], 'zero': counts['zero'], 'unique_zero': list(zero[0])}


def converted(a, role):
    if role != 'UF':
        assert isinstance(a, Q) and Q(1, 6) < a < Q(7,30)
        delta = a - Q(1, 5)
    else:
        assert len(a) == 2 and all(Q(1, 6) < v < Q(7,30) for v in a)
        delta = sum(a) - Q(2, 5)
    return Q(1, 4) + EPS * P[role] + LAM * delta


def check_sizes():
    samples = [
        (Q(1, 5), Q(1, 5), Q(1, 5), Q(1, 5), Q(1, 5)),
        (Q(19, 100), Q(19, 100), Q(19, 100), Q(19, 100), Q(19, 100)),
        (Q(21, 100), Q(21, 100), Q(21, 100), Q(21, 100), Q(21, 100)),
        (Q(2, 11), Q(7, 33), Q(7, 33), Q(2, 11), Q(7, 33)),
    ]
    for x, a, d, u, f in samples:
        conv = [converted(x,'X'), converted(a,'A'), converted(d,'D'), converted((u,f),'UF')]
        assert all(Q(1, 5) < s < 1 for s in conv)
        assert sum(conv) == 1 + LAM * (sum([x,a,d,u,f])-1)
        assert (sum(conv) <= 1) == (sum([x,a,d,u,f]) <= 1)
    return {'exact_normal_tuple_samples': len(samples), 'symbolic_identity': 'sum(new)=1+lambda*(sum(old)-1)'}


def legacy_fixed_groups(d, R, plus, minus):
    """Group inventory for K4,k=2, degree 3 at each vertex.
    'plus' / 'minus' count tree rows, *not* original tree geometry.
    """
    assert len(plus) == len(minus) == 4
    assert min(plus+minus) >= d
    Tplus, Tminus = sum(plus), sum(minus)
    Jv = [3*d*R] * 4
    J = sum(Jv)
    groups = {}
    groups['Uplus_len1__FT'] = 2*d
    groups['Uminus_len1__FT'] = 2*d
    groups['Uplus_len0__FT'] = Tplus-2*d
    groups['Uminus_len0__FT'] = Tminus-2*d
    groups['Uplus_len0__FM'] = J
    for e in range(6):
        groups[f'W_edge{e}_permit__FG'] = d*R
        groups[f'W_edge{e}_nonpermit__FG'] = d*R
    assert len(groups) == 17 and all(v > 0 for v in groups.values())

    # Count unweighted occurrences in 2 local-state templates at each v.
    # Their actual column weight is 1/2. Incidence for a group with N
    # pairs must be 2N, so assigning each physical pair 1/(2N) at
    # each occurrence gives coverage exactly 1.
    occurrences = Counter()
    for v in range(4):
        # Selected local state
        occurrences['Uplus_len1__FT'] += d
        occurrences['Uplus_len0__FT'] += plus[v]-d
        occurrences['Uminus_len0__FT'] += minus[v]
        occurrences['Uplus_len0__FM'] += Jv[v]
        # Unselected local state
        occurrences['Uminus_len1__FT'] += d
        occurrences['Uplus_len0__FT'] += plus[v]
        occurrences['Uminus_len0__FT'] += minus[v]-d
        occurrences['Uplus_len0__FM'] += Jv[v]
    # Each of six K4 edges has two endpoint-local templates, one in
    # each state; the selected state uses nonpermit and the unselected
    # state permit (dR occurrences per endpoint/state).
    for e in range(6):
        occurrences[f'W_edge{e}_permit__FG'] += 2*d*R
        occurrences[f'W_edge{e}_nonpermit__FG'] += 2*d*R

    B = Tplus + Tminus + 2*J
    assert sum(groups.values()) == B
    assert sum(occurrences.values()) == 2*B
    assert dict(occurrences) == {name: 2*n for name,n in groups.items()}
    for name,n in groups.items():
        fractional_per_copy = occurrences[name]*Q(1,2*n)
        assert fractional_per_copy == 1, (name, fractional_per_copy)
    # Source pools: +len0 = Tplus + J -2d, -len0 = Tminus-2d;
    # plus pair stocks match the source U / F inventories precisely.
    assert groups['Uplus_len0__FT']+groups['Uplus_len0__FM'] == Tplus+J-2*d
    assert groups['Uplus_len1__FT'] == 2*d
    assert groups['Uminus_len1__FT'] == 2*d
    assert groups['Uminus_len0__FT'] == Tminus-2*d
    assert sum(v for k,v in groups.items() if k.endswith('__FT')) == Tplus+Tminus
    assert groups['Uplus_len0__FM'] == J
    assert sum(v for k,v in groups.items() if k.endswith('__FG')) == J
    return {'d': d, 'R': R, 'Tplus': Tplus, 'Tminus': Tminus, 'J': J, 'B': B, 'fixed_groups': 17, 'physical_pairs': sum(groups.values()), 'local_state_tuple_occurrences': sum(occurrences.values()), 'coverage_mismatch': 0}


def check_reverse_bound():
    # Let H = abnormal 4-item bins, L= bins with at most 3 items,
    # then L<=4g, H<=12L. Replacing an abnormal four-bin costs at most
    # 7 additional bins; replacing <=3 costs at most 5 additional bins.
    for g in range(101):
        for L in range(4*g+1):
            # Worst case H=12L is sufficient because the expression
            # increases with H.
            H = 12*L
            excess = g+7*H+5*L
            assert excess <= 357*g
    return {'reverse_coefficient': 357, 'g_tested': '0..100', 'inequality': 'g+7H+5L<=357g given H<=12L,L<=4g'}


def main():
    out={'test_scope': 'exact arithmetic; abstract inventory, not source trees; no LP solver or Lean',
         'scores': check_scores(),
         'sizes': check_sizes(),
         'fixed_pair_cases': [
             legacy_fixed_groups(2,3,[4,6,8,10],[4,6,8,10]),
             legacy_fixed_groups(2,4,[5,7,8,9],[4,5,7,11]),
             legacy_fixed_groups(3,4,[8,9,10,12],[7,8,9,11]),
             legacy_fixed_groups(4,5,[12,13,14,16],[11,12,13,14])],
         'reverse': check_reverse_bound(),
         'status': 'PASS (for coded assertions only)'}
    print(json.dumps(out, indent=2, ensure_ascii=False, sort_keys=True))

if __name__ == '__main__':
    main()
