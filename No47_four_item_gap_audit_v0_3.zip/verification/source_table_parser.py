#!/usr/bin/env python3
"""Parse *actual source LaTeX* tables, not a hand-entered computed-group table.

Needs original instance.tex and completeness.tex. Exposes a parser to use only
AFTER Git blob SHA verification in verify_source_extract.py. The bundled
selftest uses a small hand-entered sample and is NOT a source verification.
"""
import ast
from fractions import Fraction
import re

SPECIES={
 r'\Up,length1': 'Uplus_len1',
 r'\Up,length0': 'Uplus_len0',
 r'\Um,length1': 'Uminus_len1',
 r'\Um,length0': 'Uminus_len0',
 r'\Waux,permitofe': 'W_permit_each_edge',
 r'\Waux,nonpermitofe': 'W_nonpermit_each_edge',
 r'\FT': 'FT', r'\FM': 'FM',r'\FG': 'FG',
}


def table_block(tex,label):
    # Restrict extraction to the table environment holding the named label.
    blocks=re.findall(r'\\begin\{table\}(?:\[[^\]]*\])?(.*?)\\end\{table\}',tex,flags=re.S)
    hits=[b for b in blocks if '\\label{'+label+'}' in b]
    if len(hits)!=1: raise AssertionError(f'Expected 1 LaTeX table {label}, found {len(hits)}')
    return hits[0]


def table_rows(tex,label):
    b=table_block(tex,label)
    if '\\midrule' not in b or '\\bottomrule' not in b: raise AssertionError('Missing table rules')
    b=b.split('\\midrule',1)[1].split('\\bottomrule',1)[0]
    b=re.sub(r'(?m)%[^\n]*$','',b)
    lines=[]
    for r in b.split(r'\\'):
        if '&' not in r: continue
        cells=[re.sub(r'\s+','',c) for c in r.split('&')]
        if any(not c for c in cells): raise AssertionError('Empty table cell')
        lines.append(cells)
    return lines


def clean_cell(cell):
    # Strip LaTeX math delimiters, convert simple macros to symbol names.
    return cell.replace('$','').replace('{','').replace('}','')


def canonical_expr(s):
    s=clean_cell(s)
    return (s.replace('t_v,+','tplus').replace('t_v,-','tminus')
             .replace('J_v','Jv').replace('t_v','tplus+tminus'))


def species_name(s):
    s=clean_cell(s)
    s=s.replace('length','length').replace('of','of')
    if s not in SPECIES: raise AssertionError(f'Unknown source species: {s}')
    return SPECIES[s]


def eval_arith(expr,values):
    node=ast.parse(expr,mode='eval')
    def rec(v):
        if isinstance(v,ast.Expression):return rec(v.body)
        if isinstance(v,ast.Constant) and type(v.value) is int:return Fraction(v.value)
        if isinstance(v,ast.Name) and v.id in ('d','tplus','tminus','Jv','dR'):
            return Fraction(values[v.id])
        if isinstance(v,ast.UnaryOp) and isinstance(v.op,ast.USub):return -rec(v.operand)
        if isinstance(v,ast.BinOp):
            a,b=rec(v.left),rec(v.right)
            if isinstance(v.op,ast.Add):return a+b
            if isinstance(v.op,ast.Sub):return a-b
            if isinstance(v.op,ast.Mult):return a*b
            if isinstance(v.op,ast.Div):return a/b
        raise AssertionError(f'Forbidden/invalid expression: {expr}')
    return rec(node)


def parse_local_state(tex):
    rows=table_rows(tex,'tab:local-state-demands')
    if len(rows)!=9:raise AssertionError(f'Expected all 9 source demand rows, got {len(rows)}')
    out={}
    for row in rows:
        if len(row)!=4:raise AssertionError(f'Unexpected source state columns {row}')
        name=species_name(row[0])
        if name in out:raise AssertionError('Duplicate source species '+name)
        out[name]={'selected':canonical_expr(row[1]),
                   'unselected':canonical_expr(row[2]),
                   'half':canonical_expr(row[3])}
    return out


def parse_patterns(tex):
    rows=table_rows(tex,'tab:patterns')
    if len(rows)!=4:raise AssertionError(f'Expected all 4 source patterns, got {len(rows)}')
    out=[]
    for row in rows:
        if len(row)!=6: raise AssertionError('Expected Kind X A U D F columns')
        clean=[clean_cell(c).replace('\\mathrm','').replace('\\','') for c in row]
        out.append(tuple(clean))
    return out

EXPECTED_PATTERNS=[
 ('M','Tp','Zanc','Up','DM','FT'),
 ('M','Tm','Zanc','Um','DM','FT'),
 ('M','Srow','Zanc','Up','DM','FM'),
 ('G','Srow','Yanc','Waux','DG','FG'),
]


def audit_tables(instance_tex,completeness_tex,transcribed):
    rows=parse_local_state(completeness_tex)
    fixture={r['species']:{'selected':r['selected'],'unselected':r['unselected']}
             for r in transcribed['roles']}
    if len(fixture)!=9 or set(rows)!=set(fixture):
        raise AssertionError('Source / fixture demand species mismatch')
    for k,v in rows.items():
        if {s:v[s] for s in ('selected','unselected')}!=fixture[k]:
            raise AssertionError(f'Source fixture mismatch for {k}: {v} vs {fixture[k]}')
    patterns=parse_patterns(instance_tex)
    if patterns!=EXPECTED_PATTERNS:
        raise AssertionError(f'Unexpected original five-role pattern table: {patterns}')
    # Verify pair species satisfy *actual parsed* U/F pattern type constraints.
    allowed={(row[3],row[5]) for row in patterns}
    if allowed!={('Up','FT'),('Um','FT'),('Up','FM'),('Waux','FG')}:
        raise AssertionError('Unexpected U-F legal type associations')
    if len(transcribed['pattern_pairs'])!=7:raise AssertionError('Expected 7 families for 17 expanded groups')
    for group in transcribed['pattern_pairs']:
        u=group['U']
        which=('Waux' if u.startswith('W_') else
               'Up' if u.startswith('Uplus') else
               'Um' if u.startswith('Uminus') else None)
        if which is None or (which,group['F']) not in allowed:
            raise AssertionError('Paired species not compatible with the original pattern table')
    # The *half of each* column is independently validated against the other 2.
    sample_values=[
       {'d':2,'tplus':10,'tminus':8,'Jv':18,'dR':6},
       {'d':7,'tplus':32,'tminus':29,'Jv':147,'dR':49},
       {'d':1,'tplus':5,'tminus':6,'Jv':12,'dR':4},
    ]
    for values in sample_values:
        for k,v in rows.items():
            predicted=(eval_arith(v['selected'],values)+eval_arith(v['unselected'],values))/2
            claimed=eval_arith(v['half'],values)
            if predicted!=claimed:raise AssertionError(f'Source half-state arithmetic mismatch: {k}')
    return {'verified_local_demand_rows':len(rows),
            'verified_five_role_patterns':len(patterns),
            'verified_pair_families':len(transcribed['pattern_pairs']),
            'expanded_pair_groups':17,
            'half_state_arithmetic_samples':len(sample_values),
            'status':'PASS'}
