#!/usr/bin/env python3
"""Source-table-derived K4 demand check; exact arithmetic, stdlib only.

The input table is a manual transcription of the primary .tex; it is not
itself a verified source. Inventory is derived independently from source
inventory formulas and Table (five-role patterns), not copied from a
previously computed fixed_groups dictionary.
"""
from pathlib import Path
from fractions import Fraction
from collections import defaultdict
import random, json, hashlib

HERE=Path(__file__).resolve().parent
DATA=json.loads((HERE/'source_local_state_table.json').read_text())
EVAL_ALLOWED={'0':lambda v:0,'d':lambda v:v['d'],'tplus+Jv-d':lambda v:v['tplus']+v['Jv']-v['d'],'tplus+Jv':lambda v:v['tplus']+v['Jv'], 'tminus':lambda v:v['tminus'], 'tminus-d':lambda v:v['tminus']-v['d'], 'dR':lambda v:v['dR'],'tplus+tminus':lambda v:v['tplus']+v['tminus'],'Jv':lambda v:v['Jv']}

def role_demand(spec, v, state):
    return EVAL_ALLOWED[spec[state]](v)

def verify_one(d,R,plus,minus,explicit_copies=False):
    assert d>=1 and R>=1 and len(plus)==len(minus)==4
    assert min(plus+minus)>=d
    # 4-vertex clique: 6 edges, three incident edges per vertex.
    edges=[(i,j) for i in range(4) for j in range(i+1,4)]
    demand=defaultdict(int); flag_demand=defaultdict(int)
    rows={r['species']:r for r in DATA['roles']}
    for v in range(4):
      vv={'d':d,'dR':d*R,'tplus':plus[v],'tminus':minus[v],'Jv':3*d*R}
      for state in ['selected','unselected']:
        for name in ['Uplus_len1','Uminus_len1','Uplus_len0','Uminus_len0']:
          # The plus len0 demand occurs in FT or FM. Derive its decomposition
          # using the entire FM flag inventory in the same local state.
          n=role_demand(rows[name],vv,state)
          if name=='Uplus_len0':
            fm=role_demand(rows['FM'],vv,state)
            demand['Uplus_len0__FM']+=fm
            demand['Uplus_len0__FT']+=n-fm
          else: demand[name+'__FT']+=n
        for kind in ['permit','nonpermit']:
          n=role_demand(rows['W_'+kind+'_each_edge'],vv,state)
          for e,(a,b) in enumerate(edges):
            if v in (a,b): demand[f'W_edge{e}_{kind}__FG']+=n
        for fl in ['FT','FM','FG']:
          flag_demand[fl]+=role_demand(rows[fl],vv,state)
    # Supply is computed from instance.tex inventories, without using the
    # demand dictionary or fixed_groups() counts.
    Tplus,Tminus=sum(plus),sum(minus)
    J=12*d*R
    supplyU={'Uplus_len1':2*d,'Uminus_len1':2*d,
             'Uplus_len0':Tplus+J-2*d,'Uminus_len0':Tminus-2*d}
    supplyF={'FT':Tplus+Tminus,'FM':J,'FG':J}
    for e in range(6):
      supplyU[f'W_edge{e}_permit']=d*R
      supplyU[f'W_edge{e}_nonpermit']=d*R
    # Derive per-pair inventory from source U pool supply, separating the
    # shared Uplus_len0 pool into FM pair and FT pair per the pattern table.
    pair_stock={'Uplus_len1__FT':supplyU['Uplus_len1'],
      'Uminus_len1__FT':supplyU['Uminus_len1'],
      'Uplus_len0__FM':supplyF['FM'],
      'Uplus_len0__FT':supplyU['Uplus_len0']-supplyF['FM'],
      'Uminus_len0__FT':supplyU['Uminus_len0']}
    for e in range(6):
      for kind in ('permit','nonpermit'):
        pair_stock[f'W_edge{e}_{kind}__FG']=supplyU[f'W_edge{e}_{kind}']
    assert len(pair_stock)==17 and all(x>0 for x in pair_stock.values())
    assert set(demand)==set(pair_stock)
    for k,n in pair_stock.items():
      assert demand[k]==2*n,(k,demand[k],n)
      if explicit_copies:
        for copy_i in range(n):
          # Every source occurrence had coefficient 1/2, split equally
          # across the n physical pairs in its group.
          assert sum((Fraction(1,2*n) for _ in range(demand[k])),Fraction(0))==1
    assert flag_demand=={'FT':2*supplyF['FT'],'FM':2*supplyF['FM'],'FG':2*supplyF['FG']}
    assert sum(pair_stock.values())==Tplus+Tminus+2*J
    return {'B':sum(pair_stock.values()),'groups':17,'fractional_occurrences':sum(demand.values()),'coverage_mismatch':0}

def main():
    tests=[]
    tests.append(verify_one(2,3,[4,6,8,10],[4,6,8,10],True))
    rng=random.Random(4702)
    for i in range(200):
      d=rng.randrange(1,7);R=rng.randrange(1,9)
      plus=[d+rng.randrange(1,30) for _ in range(4)]
      minus=[d+rng.randrange(1,30) for _ in range(4)]
      tests.append(verify_one(d,R,plus,minus,i<5))
    out={'verification':'source-local-state demands independently expanded to physical pair supply',
         'source_fixture_sha256':hashlib.sha256((HERE/'source_local_state_table.json').read_bytes()).hexdigest(),
         'abstract_parameter_sets':len(tests),'verified_groups_per_case':17,
         'nonzero_mismatches':0,'representative':tests[0],
         'limits':'Manually transcribed source table; not giant original instance or full .tex parsing.'}
    print(json.dumps(out,indent=2,sort_keys=True,ensure_ascii=False))

if __name__=='__main__': main()
