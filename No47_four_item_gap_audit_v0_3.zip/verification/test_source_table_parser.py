#!/usr/bin/env python3
"""Parser smoke test only: fixture excerpts are hand-entered, NOT original-source authentication."""
from pathlib import Path
import json,sys
S=Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0,str(S))
from source_table_parser import audit_tables

INSTANCE=r'''
\begin{table}[htbp]
\centering
\begin{tabular}{c c c c c c}
\toprule
Kind & $X$ & $A$ & $U$ & $D$ & $F$\\
\midrule
$\mathrm M$ & $\Tp$ & $\Zanc$ & $\Up$ & $\DM$ & $\FT$\\
$\mathrm M$ & $\Tm$ & $\Zanc$ & $\Um$ & $\DM$ & $\FT$\\
$\mathrm M$ & $\Srow$ & $\Zanc$ & $\Up$ & $\DM$ & $\FM$\\
$\mathrm G$ & $\Srow$ & $\Yanc$ & $\Waux$ & $\DG$ & $\FG$\\
\bottomrule
\end{tabular}
\label{tab:patterns}
\end{table}
'''
COMPLETE=r'''
\begin{table}[htbp]
\centering
\label{tab:local-state-demands}
\begin{tabular}{@{}lccc@{}}
\toprule
Species & Selected & Unselected & Half of each\\
\midrule
$\Up$, length $1$ & $d$ & $0$ & $d/2$\\
$\Up$, length $0$ & $t_{v,+}+J_v-d$ & $t_{v,+}+J_v$ & $t_{v,+}+J_v-d/2$\\
$\Um$, length $1$ & $0$ & $d$ & $d/2$\\
$\Um$, length $0$ & $t_{v,-}$ & $t_{v,-}-d$ & $t_{v,-}-d/2$\\
$\Waux$, permit of $e$ & $0$ & $dR$ & $dR/2$\\
$\Waux$, nonpermit of $e$ & $dR$ & $0$ & $dR/2$\\
$\FT$ & $t_v$ & $t_v$ & $t_v$\\
$\FM$ & $J_v$ & $J_v$ & $J_v$\\
$\FG$ & $J_v$ & $J_v$ & $J_v$\\
\bottomrule
\end{tabular}
\end{table}
'''

# Minimal source excerpt uses t_v; the checker canonicalizes it to tplus+tminus.
fixture=json.loads((S/'source_local_state_table.json').read_text(encoding='utf-8'))
result=audit_tables(INSTANCE,COMPLETE,fixture)
for altered in (COMPLETE.replace(r'\FG$ & $J_v$ & $J_v$ & $J_v$',r'\FG$ & $J_v$ & $0$ & $J_v$'),
                COMPLETE.replace(r'\FM$ & $J_v$ & $J_v$ & $J_v$',r'\FM$ & $J_v$ & $0$ & $J_v$'),
                COMPLETE.replace(r'\FT$ & $t_v$ & $t_v$ & $t_v$',r'\FT$ & $t_v$ & $0$ & $t_v$')):
    try:audit_tables(INSTANCE,altered,fixture)
    except AssertionError:pass
    else:raise AssertionError('FAIL negative test did not detect mutated flag')
try:audit_tables(INSTANCE.replace(r'\FG$',r'\FT$'),COMPLETE,fixture)
except AssertionError:pass
else:raise AssertionError('FAIL mutated source pattern escaped detector')
print(json.dumps({'parser_smoke':'PASS','local_state_rows':result['verified_local_demand_rows'],
                 'five_role_patterns':result['verified_five_role_patterns'],
                 'negative_mutations_detected':4,
                 'source_authentication':'NOT TESTED (requires five original .tex files)'},
                 ensure_ascii=False,sort_keys=True,indent=2))
