#!/usr/bin/env python3
"""Fail-closed SHA-256 manifest verification of No47 audit package."""
from pathlib import Path
import hashlib
import sys

base = Path(__file__).resolve().parent.parent
manifest = base / 'SHA256SUMS.txt'
if not manifest.is_file():
    raise SystemExit('FAIL: SHA256SUMS.txt missing')
expected = {}
for line in manifest.read_text(encoding='utf-8').splitlines():
    if not line.strip():
        continue
    sha, sep, relative = line.partition('  ')
    if not sep or len(sha)!=64 or any(c not in '0123456789abcdef' for c in sha):
        raise SystemExit('FAIL: malformed checksum record: '+line)
    p = (base / relative).resolve()
    if not p.is_relative_to(base.resolve()) or relative in expected:
        raise SystemExit('FAIL: unsafe / duplicate manifest path: '+relative)
    expected[relative] = sha
actual = {str(p.relative_to(base).as_posix()) for p in base.rglob('*') if p.is_file() and p.name!='SHA256SUMS.txt'}
if actual != set(expected):
    raise SystemExit('FAIL: missing/unlisted files: '+str({'missing': sorted(set(expected)-actual), 'unlisted':sorted(actual-set(expected))}))
for name, sha in sorted(expected.items()):
    have = hashlib.sha256((base/name).read_bytes()).hexdigest()
    if have != sha:
        raise SystemExit(f'FAIL: {name}: expected {sha}, got {have}')
print(f'PASS: {len(expected)} files match SHA256SUMS.txt')
