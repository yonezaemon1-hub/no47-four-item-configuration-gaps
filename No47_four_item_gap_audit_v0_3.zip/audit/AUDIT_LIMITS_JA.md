# No.47 v0.3 監査メモ — 誤認防止

## 依存関係

1. OpenAI (2026) Table (five-role patterns) and item inventory の役割5つ各B品、サイズが(1/6,7/30)、K4(k=2)のU/F在庫定義。
2. OpenAI Proposition (fractional) / Table (local-state demands) の selected/unselected local state 分数証明、テンプレートは各重み1/2、各テンプレートにX,A,U,D,Fを1個ずつ含む。
3. OpenAI Theorem (Unbounded configuration gap) の K4(k=2)構成に対する任意の加法ギャップ（source unbounded theorem）。

これらを再証明したわけではない。原文の版が変わった場合は再照合が必要。

## 今回検算した範囲

- p=(1,2,4,-7) の4個重複組合せ35通りを Python で列挙、スコア0は正常1種類のみ。
- 新規品物サイズ >1/5 の粗い有理数境界と正常箱のサイズ恒等式。
- K4の17群について source Proposition (fractional) の selected/unselected需要数からコピー数2倍恒等式、抽象パラメータ4例＋別実装201例。
- H<=12L, L<=4g より OPT_5<=B+357g の一般的な数え上げ。

## 重要な未完事項

- 元論文の **実** 巨大な木、時間セル、deadline、および全5品配置の実生成・全リスト照合。
- 別実装による数学的証明の敵対的再監査、Lean等の形式証明。
- 先行研究に >1/5 の同一強化が既にないかの包括的調査（NOVELTY INCONCLUSIVE）。
- 構成のサイズ（ビット長）を固定加法cの多項式時間還元として保証する議論、固定ペアの整数YES解保存。**NP困難性は主張しない**。

## 今回の実測として主張しない数字

以前の会話に出た「19,296列」「24,000列」などは、このZIPで再現するコード・原始ログが無いため採用しない。実際に今回走らせたのは `verification_results.json` の4例であり、列の総数は元論文の実インスタンス全体の個別列挙件数ではない。

## 公開可否

`RELEASE = HOLD`、`PROOF = DRAFT / SOURCE-CONDITIONAL`、`COMPUTATION = PASS for code assertions`、`NOVELTY = INCONCLUSIVE`。

独立監査に回すことは可能だが、公開済み定理や人間査読済みとは表記しない。

## v0.2で追加した確認
- OpenAI `introduction.tex` で Theorem (Unbounded configuration gap) を確認。主張は >1/6、最大5品であり、>1/5 または4品への直接的強化は発見されなかった（網羅的先行調査ではない）。
- 原文 `instance.tex` Lemma (scalar encoding) は a_i ∈(1/6,7/30) を与える。
- 原文の `main.tex` 抄録でも >1/6、最大5品を確認。
- `indep_table_check.py` は source table を転記したJSONから群需要を導き、UとFの在庫を別経路から構成。200乱数ケースと1固定ケース。なお原文を実時取得して機械的解析したものではない。
- `verify_source_extract.py` は原文 .tex を外部取得した審査者が任意実行するもので、ZIP作成時には未実行。
- 外部先行研究の同一4品強化は確認できず、NOVELTY INCONCLUSIVEを維持。
- 元の正確な巨大構成/Lean形式証明/人間査読/原文PDFの画面上の照合は未完了。

## v0.3 再現性監査での追加修正

- `python -I` で全標準チェックを動作させるように変更。
- `verify_source_extract.py` は原文の5ファイルのGit blob SHAを照合後、局所状態表の9行と5役パターン表4行をパースし、JSONと食い違えばFAILにする。FT/FM/FGも含む。
- `test_source_table_parser.py` のデータは説明用に手入力したサンプル。**原論文のTeX全体を今回再読込した証拠ではない**。
- 前回のような「JSONは手転記」の制約は残る。原文と照合する任意検証の通過が確認されるまではSOURCE-AUTHENTICATEDとは扱わない。
- 数学的な証明部分はv0.2から変更なし。別監査のSOURCE-CONDITIONAL PASSを引き継ぎ、RELEASE HOLD維持。
