# Four-Item Unbounded Configuration Gaps via a Paired-Auxiliary Reduction

**No. 47 — research manuscript / adversarial-audit draft v0.3 (2026-11-01)**  
**Author:** Ryutaro Yonezu — Independent Researcher  
**Status:** PREPRINT DRAFT, RELEASE HOLD; not human peer-reviewed; novelty INCONCLUSIVE.  
**Dependency:** The OpenAI 2026 five-role construction, including its instance inventory and fractional certificate. Not an independent proof of the source theorem.

## Abstract

We formulate and analyze a fixed-pair auxiliary reduction for the rational one-dimensional bin-packing configuration linear program. Applied to the structured five-role instances used in the 2026 OpenAI unbounded-gap construction, it replaces a pair of roles by one composite item, obtaining an instance with all sizes strictly larger than one fifth. The constructed fractional certificate has objective B, while any packing into B+g bins can be decoded into a packing of the original instance into at most B+357g bins. Assuming the source construction and fractional templates as stated, this yields unbounded additive gaps for bin packing with at most four items per bin. The reduction is *not* a proof of fixed-additive NP-hardness; its completeness direction for integer packings is not established here. Novelty and independent external verification remain unresolved.

## 1. Definitions and imported input

A bin has capacity one. A configuration is any multiset of item copies with total size at most one. Write LP(I) for the usual covering configuration-LP optimum and OPT(I) for the minimum integer number of bins. For each gap parameter h, use the particular K4, k=2 instance furnished by the unbounded-gap construction in:

OpenAI (2026), *Additive hardness and unbounded configuration gaps in bin packing*, the source **Unbounded configuration gap** theorem and its **Proposition (fractional)**, **Lemma (scalar encoding)**, and **Table (local state demands)**; see `audit/SOURCE_REFERENCES.json`.

The input required here has five **roles** X, A, U, D, F, each with exactly B copies, for 5B total items. The source Lemma (scalar encoding) proves the sharper bound a_i ∈ (1/6, 7/30). For each h the source proves, using its graph-to-packing construction and soundness argument, that its fractional solution has value B and that OPT_5 > B+h. More specifically, its fractional solution comprises local selected/unselected state templates of weight 1/2, one item from each role per template; its Proposition (fractional) uses independent fractional choices of U and F copies. We use only these specially structured source instances, not an arbitrary five-role bin-packing instance.

The source inventory in `instance.tex` uses plus- and minus-tree counts t_{v,+},t_{v,-} at the four graph vertices, J_v=dR deg(v), and symbols

- T_+ = sum_v t_{v,+}, T_- = sum_v t_{v,-}, J = sum_v J_v;
- B = T_+ + T_- + 2J;
- FT, FM, FG flags, with total inventory T_+ + T_-, J, J respectively;
- plus- and minus-U at lengths 1 and 0, and W auxiliaries indexed by one of six K4 edges and permit status.

The source inventory assigns constant size within each such U subtype and within each flag subtype; this follows from the score encoding and coordinates in **Lemma (scalar encoding)** and the inventory paragraphs in `instance.tex`. The X, A, and D roles may have different numerical sizes between individual copies.

## 2. Lemma: fixed pairing preserves the source fractional witness

Partition the physical U and F copies into the following 17 groups of **pairs**:

| Pair group | Pairs N | Number of half-weight local-state occurrences |
|---|---:|---:|
| (U+ length 1, FT) | 2d | 4d |
| (U- length 1, FT) | 2d | 4d |
| (U+ length 0, FT) | T_+ - 2d | 2(T_+ - 2d) |
| (U- length 0, FT) | T_- - 2d | 2(T_- - 2d) |
| (U+ length 0, FM) | J | 2J |
| (W_e permit, FG), each e of 6 edges | dR per edge | 2dR per edge |
| (W_e nonpermit, FG), each e of 6 edges | dR per edge | 2dR per edge |

The last two rows stand for 12 separate groups. The pair inventories exhaust both U and F physical stocks, because U+ length-0 total is T_+ + J - 2d, U- length-0 total is T_- - 2d, the length-1 pools have 2d copies each, and the W pools contribute 12dR = J copies on K4. Hence the total number of pairs is B.

**Why occurrence counts are correct.** From **Table (local state demands)** in `completeness.tex`, at vertex v: selected state uses d U+ length-1, t_{v,+}-d U+ length-0 in FT tree slots, t_{v,-} U- length-0 in FT tree slots, J_v U+ length-0 in FM slots, and dR nonpermits for each incident edge. The unselected state instead uses d U- length-1, t_{v,+} U+ length-0 FT, t_{v,-}-d U- length-0 FT, J_v U+ length-0 FM, and dR permits for each incident edge. Summing over four vertices gives the right column. Every edge has two endpoints.

**Fractional rearrangement.** Every occurrence is a selected- or unselected-state local slot with original coefficient 1/2. For a group of N identical-size U-F pairs, split that coefficient into N configurations, each using one of its physical paired copies, with coefficient 1/(2N). Every physical pair belongs to 2N half-weight occurrences, so its total covering weight is (2N)/(2N)=1. **For X, A, and D, a physical copy occurs in exactly one local template in each of the selected and unselected states. Splitting each such weight-1/2 template across N pairs changes its total coefficient by N·(1/(2N)) = 1/2. Hence every labeled physical copy remains covered with total weight 1.** (No equal-size assumption about X/A/D is needed.) All split configurations remain feasible since each group has fixed U and F numerical sizes. The summed objective remains B.

Thus the paired five-role fractional witness is feasible with objective B. This lemma uses the local templates whose feasibility is established in the source **Proposition (fractional)**, not an independent construction of its trees or deadlines. The group-demand proof relies on the particular class/flag assignments in **Table (five-role patterns)**, and not solely on the aggregate table of U-demands.

## 3. Lemma: map five roles to four, with sizes >1/5

Replace each fixed pair (u,f) by a new composite item UF, leaving all X,A,D copies unchanged. There are exactly B of each of the four new roles, and 4B new physical items.

Assign integer role scores

    p_X=1, p_A=2, p_D=4, p_UF=-7.

Put epsilon=1/1000, lambda=1/100000. Define the new sizes using source sizes a:

    s'(i)=1/4+epsilon*p_role+lambda*(a_i-1/5)            for X,A,D;
    s'(u,f)=1/4-7*epsilon+lambda*(a_u+a_f-2/5)         for UF.

The source **Lemma (scalar encoding)** proves the sharper bound a_i ∈ (1/6, 7/30). Thus a_i-1/5 ∈ (-1/30,1/30) and a_u+a_f-2/5 ∈ (-1/15,1/15). Consequently every new item lies strictly in (1/5,1). Hence a feasible new bin contains at most four items.

In any new four-item bin, let P be the total role score. The total lambda-correction has absolute value strictly below 4*(1/15)*lambda, which is less than epsilon. (The coarser v0.1 bounds also suffice.) Thus P>=1 forces the bin size to exceed 1. Exhaustive enumeration of the 35 multisets of four roles with replacement shows that the only multiset with P=0 is {X,A,D,UF}; the other 34 have nonzero integral P. In particular, a feasible abnormal four-item bin has P<=-1.

For a normal four-role bin, p totals zero, and the source-subtraction constants sum to 1. Hence the **exact identity**

    sum(new sizes)=1+lambda*(sum(of five corresponding source sizes)-1).

Therefore feasibility of a normal new bin implies feasibility of the corresponding original five-item bin.

## 4. Lemma: decode an arbitrary near-perfect integer packing

Suppose the transformed instance has an arbitrary integer packing into B+g bins, g>=0 integer. Let L be its number of bins with at most three items, and H its number of abnormal four-item bins. Every normal four-item bin carries score 0 and every abnormal feasible four-item bin carries score at most -1. The global role-score sum is B*(1+2+4-7)=0, while a bin with at most three items has role-score at most 12. Hence H<=12L.

Exactly 4B items occupy at most 4(B+g) slots, so the sum of missing slots is 4g. Every bin counted by L has at least one missing slot; thus L<=4g and H<=48g.

Decode each normal four-item bin into its original five-item bin; this is feasible by §3. For an abnormal four-item bin, replace the bin by singletons of the corresponding original items (at most 8 source items), costing at most 7 additional bins. For each bin with at most three composite/ordinary items, replace it by singletons (at most 6 original items), costing at most 5 additional bins. Singleton source items have size less than one.

The source instance is thereby packed into at most

    (B+g)+7H+5L <= B+g+7*(48g)+5*(4g) = B+357g

bins. In particular, **OPT_5 <= B+357g** for any such packing of the transformed instance.

The decoding does not assume any relation between an integer packing and the fractional template support.

## 5. Theorem: unbounded four-item additive gaps, conditional on the imported source theorem

**Theorem (reduction corollary).** For every c>=0 there is a finite rational bin-packing instance I_4 with all item sizes >1/5, both individual-copy and numerical-type configuration-LP values B, and OPT(I_4)>B+c.

**Proof.** For h=357c use the source K4 family for which OPT_5>B+h. Apply §2 to its source fractional certificate, then merge its pairs and transform sizes as in §3. This gives a feasible individual-copy LP solution of value B. Since there are 4B items and every feasible bin contains at most four, the fractional objective is at least B by the cardinality dual. Hence LP_copy=B. Projection to numerical types gives LP_type=B as well, since each type has size >1/5 and the cardinality dual still gives the lower bound B.

If OPT_4<=B+c, the decoding lemma in §4 yields OPT_5<=B+357c, contradiction. Thus OPT_4>B+c. Since c was arbitrary, the additive gaps are unbounded. QED, conditional on the cited source construction/theorem and source fractional-template feasibility.

## 6. Explicit limitations

1. This is an original **reduction candidate**, not an independent proof of the source OpenAI #118 theorem. The source manuscript and its assumptions must be accurately cited.
2. The 17-group split uses the source K4, k=2 fractional witness; this argument is **not** a general pairing theorem for arbitrary five-item instances.
3. The fixed U-F pairing need not preserve integer *completeness*. No claim is made that the fixed-additive NP-hardness reduction strengthens to >1/5.
4. The included checkers test role scores, exact-size identities, and source-table-derived abstract fractional demand arithmetic. They neither generate the actual huge competing-tree instance nor formally check all source lemmas. `verification/source_local_state_table.json` is a manually transcribed primary-source fixture; it can be compared with the original `completeness.tex` using `verify_source_extract.py` when the reviewer provides source files.
5. No independent human peer review, Lean proof of the new reduction, or exhaustive prior-art search has been completed. The source introductory theorem states **>1/6**, and we did not find a **>1/5** strengthening in the checked TeX, but this is not evidence of global novelty. The official PDF was not visually inspected in this ZIP revision; primary TeX was checked. Release: HOLD. Novelty: INCONCLUSIVE.

## 7. References

- OpenAI (2026), *Additive hardness and unbounded configuration gaps in bin packing*. Official repository, source sections `instance.tex`, `completeness.tex`, `consequences.tex`, https://github.com/openai/math/tree/main/preprints/Additive-hardness-and-unbounded-configuration-gaps-in-bin-packing-September-24-2026 .
- Hoberg, R. and Rothvoss, T. (2017), *A logarithmic additive integrality gap for bin packing*, SODA, DOI: 10.1137/1.9781611974782.172.

## v0.3 verification provenance note

This revision changes only the reproducibility infrastructure and editorial provenance, not the mathematical proof: the source is authenticated by Git blob hashes only if its five original TeX files are supplied. The optional verification then parses **all nine** local-state demand rows, including FT, FM and FG, and **all four** five-role pattern rows. The bundled parser smoke sample does not authenticate or reconstruct the original OpenAI instance. The stronger bound $1/6<a_i<7/30$ is unchanged. Publication remains on HOLD.
