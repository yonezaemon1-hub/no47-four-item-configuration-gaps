# No.47 v0.3 — 敵対的監査用ZIP（公開HOLD）

**論文候補:** Four-Item Unbounded Configuration Gaps via a Paired-Auxiliary Reduction  
**著者:** Ryutaro Yonezu — Independent Researcher  
**状態:** 数学 SOURCE-CONDITIONAL / PROOF DRAFT、NOVELTY INCONCLUSIVE、RELEASE HOLD、人間査読なし。  
**元論文:** OpenAI (2026), *Additive hardness and unbounded configuration gaps in bin packing*。

## 主要内容

- `manuscript/No47_PROOF_DRAFT_EN.md`: 証明候補全文。前回の§2 X/A/D被覆理由を訂正、参照を命題/補題/表に修正、原文サイズ境界 (1/6,7/30) を反映。
- `verification/verify_no47.py`: 有理数算術・35組合せ・357g上界と原文表から導く17群を呼び出して検査。
- `verification/source_local_state_table.json`: 原論文の局所状態表・模式対応の転記データ（原文そのものではない）。
- `verification/indep_table_check.py`: 原論文表由来の局所需要から各群とコピー被覆を再導出する別実装（`verify_no47.py` も利用）。
- `verification/legacy_inventory_regression.py`: v0.1の在庫公式を自己入力した旧チェッカー（旧出力比較専用、独立監査根拠にはしない）。
- `verification/verify_source_extract.py`: 原論文5本のTeXを用意した場合に、Git blob SHA全件を照合し、局所需要表9行（FT/FM/FGを含む）と5役パターン表4行を機械解析して照合するオプション。
- `verification/source_table_parser.py`: 原文の表から需要とパターンを抽出するパーサー（読み取り失敗はFAIL）。
- `verification/test_source_table_parser.py`: 小さな手入力TeXサンプルによるパーサーの動作・改変検出テスト。原文認証ではない。
- `verification/*_results.json`: 実際に実行した検証結果。
- `audit/SOURCE_REFERENCES.json`: GitHub原文とGit blob SHA（導入・主定理を含む）。
- `audit/AUDIT_LIMITS_JA.md`: 限界・未確認事項。
- `SHA256SUMS.txt`: ZIP内の他のファイルのSHA256一覧。

## ローカル検証（追加ライブラリ不要）

```sh
python -I verification/verify_no47.py
python -I verification/indep_table_check.py
python -I verification/test_source_table_parser.py
python -I verification/check_hashes.py
```

原文 `.tex` を本人が取得済みの場合のみ：

```sh
python -I verification/verify_source_extract.py /path/to/source-tex-directory
```

**主張の範囲:** OpenAIの5品無限ギャップ定理と分数テンプレートを輸入した4品への還元候補。元定理を独立に証明したものではない。NP困難性の強化は主張しない。ZIP内の抽象検算は巨大な実インスタンスの生成・全列挙の代用ではない。

**公開は許可されていない。**

## v0.3変更点と監査限界

- `python -I` 対応。`verify_no47.py` が自分の検証フォルダだけを `sys.path` に追加し、標準ライブラリ以外を要求しない。
- 原文との機械照合を **9行+4パターン** に拡張。オリジナルファイルの Git blob SHA が一致しなければ FAIL。原文は同梱しない。
- JSON は引き続き**人手転記**。本ZIP内の `test_source_table_parser.py` のPASSだけでは原文一致を主張しない。
- `verify_no47.py` の `delta` 範囲コメントを `(-1/30,1/30)`／`(-1/15,1/15)` に訂正。数学の定理・357g上界はv0.2から不変。
- ZIP生成時には原文5本のオフラインファイルがないため `verify_source_extract.py` の**実原文経路を再実行していない**。監査者が原文を取得して照合すること。
- 分数LPの証人は原論文の構成に依存。独立実インスタンス再生成、Lean、人間査読、新規性の確認は未実施。公開HOLD。
